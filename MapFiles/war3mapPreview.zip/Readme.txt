War3mapPreview.TGA is provided as a sample preview minimap.
A "preview minimap" is show in Warcraft 3 when you select a map in a custom game or on the net. It only replace the "in-game" minimap in the preview screens, not while you are playing. When you are playing, you'll still have you old minimap.
It's an optional file: if you want a preview minimap, just extract this file in the current directory (should be something like "path_to_W3Z\MapFiles") and leave its name unchanged. If you want, you can customize it as long as you use a War3-compatile TGA format (RGB 32bit uncompressed) when you save your preview minimap. You just need to replace war3mapPreview.TGA with your own TGA (you have to use the exact same name or my editor wont find it).
Keep in mind that a preview map can add several Kbytes to your map file!

   -=Z�pir oo